from ocr_backend import run

print run.run(2, "/home/andy/image_base/images/bear_c/Main_2016-01-04_16:13:53_2556.JPG")