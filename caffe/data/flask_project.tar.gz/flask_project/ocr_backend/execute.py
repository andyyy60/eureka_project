import crop_and_recognize


print crop_and_recognize.main(2, "/home/andy/image_base/images/bear_c/Main_2016-01-04_16:13:53_2556.JPG")